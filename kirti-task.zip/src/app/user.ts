export interface User {
    id?: string;
  fname:string;
  lname:string;
  email:string;
  mobile:number;
  age:number;
  state:string;
  country:string;
  address:string;
  ischeck:boolean;
}